NFOView v1.5
------------

Coded by: m0nngis / dfg.
Web: http://www.dfg-crew.com
Mail: mongo@dfg-crew.com

Good ol' freeware.

This is a program designed especially for viewing
.NFO files that come with scene releases.
These files usually have some intricate ASCII art
designed to be viewed with the right font.
Checking them out in Notepad or something sucks,
so I decided to make this program on the request from a
friend of mine.

You can associate NFOView with .nfo files by running

'nfoview.exe /associate'

Otherwise the syntax is 'nfoview.exe [nfo file]'
Oh, and you can drag and drop files on the GUI as well.

Yay.


Changelog:

Oct 25 2005: v1.4
  - Fixed bug re: file association. File name/paths with
    spaces didn't work.

Oct 29 2005: v1.5
  - Didn't fix it in v1.4... file association should work
    _now_, though...