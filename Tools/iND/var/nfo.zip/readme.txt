nfo.dll 1.0.0.0

mirc plugin for getting infos about tv shows from tvrage. 
Usage:
alias tv {
 echo 10 -bfgm $dll(nfo.dll, tv, $1-)
}
Download: nfo.dll 