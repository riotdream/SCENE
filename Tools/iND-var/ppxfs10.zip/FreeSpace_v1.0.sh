#!/bin/sh 

# This script has a look at your free space status. If your hard   :|
# disk is fuller than XX percent (you can configure it in the      :|
# script..) you will get a email, shellmail message,               :|
# net send message for our windows using friends or a global       :|
# shell message.                                        

config()
{

maxuse="90" # if hard disk is fuller than $maxuse (e.g. 90) percent the script will run.
shelluser="root@localhost" # the shell user for the shell message.
winsname="perplex-empire" # winsname for net send message.  
emailaddy="root@localhost" # email address

# set the alert strings to "on" or "off" how you want it 
mailmsg="off" # mail to shelluser  
scripttest="off" # simple echo output for testing
globalmsg="on" # global shell msg 
netsend="on" # a msg from smbclient to a windows machine
emailmsg="off" # email to a user

}

#
# .:!:. dont touch this lines !!! .:!:.
#

hardvars()
{
diskfree=`df -h`
dflines=`echo "$diskfree" | wc -l`
dflines=`expr $dflines - 1`
prozahl=`echo "$diskfree" | awk '{print $5}' | tail -n$dflines | sed -e 's/%//g'`
}

alertpart()
{

if [ "$mailmsg" = "off" ] && [ "$netsend" = "off" ] && [ "$globalmsg" = "off" ] && [ "$scripttest" = "off" ] && [ "$emailmsg" = "off" ] 
then
 echo "all alertconfigs are off ! " | wall 
 exit 
fi 
if [ "$mailmsg" = "on" ]
then
 echo "$alertinfo" | mail "$shelluser" 
fi 
if [ "$netsend" = "on" ]
then
 echo "$alertinfo" | smbclient -M "$winsname"
fi
if [ "$globalmsg" = "on" ]
then
 echo "$alertinfo" | wall
fi
if [ "$scripttest" = "on" ]
then
 echo "$alertinfo" 
fi
if [ "$emailmsg" = "on" ]
then
 echo "$alertinfo" | mail "$emailaddy" 
fi

}

badchars()
{
mailmsg=`echo $mailmsg | tr A-Z a-z`  
scripttest=`echo $scripttest | tr A-Z a-z`
globalmsg=`echo $globalmsg | tr A-Z a-z`
netsend=`echo $netsend | tr A-Z a-z`
emailmsg=`echo $emailmsg | tr A-Z a-z`
}

main()
{
for check in $prozahl
do 
 if [ $check -ge $maxuse ]
 then
  slcfrmb=`echo "$diskfree" | grep $check% | awk '{print $4}'`
  slcuspr=`echo "$diskfree" | grep $check% | awk '{print $5}'`
  slcus=`echo "$diskfree" | grep $check% | awk '{print $2}'`
  slcmnt=`echo "$diskfree" | grep $check% | awk '{print $6}'`
  alertinfo="The Partition "$slcmnt" is to "$slcuspr" full, "$slcfrmb" are free from "$slcus""
  alertpart      
 fi
done
}

config
hardvars
badchars
main


